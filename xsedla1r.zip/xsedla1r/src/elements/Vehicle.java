/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package elements;

import Carriage.TimePoint;
import Order.IOrder;
import Order.Order;
import javafx.scene.paint.Color;
import javafx.scene.shape.Polyline;
import javafx.scene.shape.Rectangle;
import map.IWarehouseMap;
import java.awt.Point;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import map.WarehouseMap;

/**
 * animation of carriage
 * @author xzbori21
 */
public class Vehicle extends Rectangle {

    Map<Integer, java.util.List<Order>> orders;

    private ArrayList<Point> path;
    private ArrayList<Point> stop;
    private ArrayList<TimePoint> timePoints;

    /*PRO OJBJIZDNOU TRASU*/
    private ArrayList<Point> indexes;

    private int mapIndex = 0;
    private int stopIndex = 0;
    private boolean finished = false;
    private IWarehouseMap map;

    private int sleep = 0;
    private boolean takingGood = false;

    public Point getNextPoint(int index) {
        if (index < this.path.size()) {
            return this.path.get(index);
        } else {
            return this.path.get(index - 1);
        }
    }

    public Point getNextStop(int index) {
        
        return this.stop.get(index);
    }
    
    
    public Vehicle(Map<Integer, List<Order>> orders, IWarehouseMap map, ArrayList<Point> path, ArrayList<Point> stop, ArrayList<Point> indexes) {
        this.orders = orders;
        this.map = map;
        this.path = path;
        this.stop = stop;
        this.setFill(Color.BLACK);
        this.setWidth(20.0);
        this.setHeight(20.0);
        this.map = map;
        this.timePoints = new ArrayList<>();
        this.indexes = indexes;
    }

    public void addTimePoint(TimePoint point) {
        if (!this.timePoints.contains(point)) {
            this.timePoints.add(point);
        }
    }
    
    public void setGoodPicked(int timestamp, WarehouseMap warehouse){
        int min = 0;
        int time = 0;
        
        List sortedKeys = new ArrayList<>(orders.keySet());    
        Collections.sort(sortedKeys);

        for(Object i : sortedKeys){
            System.out.println(i);
        }
        
        int index = (int)sortedKeys.get(this.stopIndex-1);
        
        orders.get(index).get(0).setTimeStamp(timestamp);
        
        System.out.println("NEXT:" + index + " and stop inex "+ this.stopIndex);
        warehouse.removeGoodFromShelf(index, orders.get(index));
    }
    
    public void printIndexes() {
        for (Point p : this.indexes) {
            System.out.println("( " + p.x + " , " + p.y + " )");
        }
    }

    public int getIndexesSize() {
        return this.indexes.size();
    }

    public Point getCenteredIndex(int index) {
        Point p = this.indexes.get(index);
        int rc = p.x - p.x / 3;

        if (rc % 2 == 1) {
            //indexes.add(new Point(row - 1, column));
            return new Point(p.x - 1, p.y);

        } else {
            //indexes.add(new Point(row + 1, column));
            return new Point(p.x + 1, p.y);

        }
    }

    public String printCurrentLoad(int timestamp){
        String text = "";
        int count = 1;
        
        for(Map.Entry<Integer, List<Order>> key : this.orders.entrySet()){
            if(key.getValue().get(0).getTimeStamp() != -1 && key.getValue().get(0).getTimeStamp() <= timestamp){
                for(Order o : key.getValue()){
                    if(count %3 == 0){
                        text +="\n";
                    }
                    text += o.getName() + " - " + o.getCount() + "; ";
                    count++;
                }
            }
        }
        
        return text;
        
    }
    
    public Point nextPath(int row, int column) {
        Point p = new Point();
        //Pro vypocet stejne ulicky
        p.x = 200 + 40 * row + 10;

        p.y = 50 + 40 * column + 20;

        return p;
    }
 
    
    public void findNewPath(Shelf[][] shelfs, int row, int col, boolean barrier) {
        /*aktualni index v mape bodu - this.mapIndex
         *Staci me projet body od mapIndex po konec a zkontrolovat novou body
        
         */
        int maxY = (shelfs[0].length - 1) * 40 + 60 + 30;

        int width = (int)shelfs[0][0].getWidth();
        int height = (int)shelfs[0][0].getHeight();
        ArrayList<Point> points = new ArrayList<>();
        //ArrayList<Point> stops = new ArrayList<>();
        
        
        for (int i = 0; i < this.mapIndex + 1; i++) {
            points.add(this.path.get(i));
        }    
        //System.out.println("----------------");

        //System.out.println("ENDING");
        
        int index = points.size() - 1;
        
        this.path.clear();
       
        //this.stop.clear();
              
        
        /*for(int i =0; i< this.stop.size(); i++){
            Point p = this.stop.get(i);
            Point p2 = this.indexes.get(i);
            //System.out.format("%d (%d,%d) - (%d, %d)\n", i, p.x,p.y, p2.x, p2.y);
        }*/       
        
        Point max = points.get(points.size() - 1);

        System.out.println(max.x + " " + max.y);
        
        if(max.y < 30){
            max.y = 30;
        } else if(max.y > maxY-30){
            max.y = maxY-30;
        }
       //350 - 30
        
        int dirX = (max.x - 200)/40;
        
        int dirY = (max.y - 30)/40;
        
        
        
        if(dirY == shelfs[0].length){
            dirY = shelfs[0].length - 1;
        }
        
        int dirBefore = 0;
        
        

       
        if(dirX >= 0 && dirX < shelfs.length && dirY >= 0 && dirY < shelfs[0].length){
            
            Point barrierCoor = nextPath(row, col);
            
                if(this.getX() == barrierCoor.x){                    
                    if(this.getY() < barrierCoor.y){
                        if(col != 0){
                            dirY = col-1;
                        }
                    } else if(this.getY() > barrierCoor.y){
                        if(col != shelfs[0].length - 1){
                            dirY = col + 1;

                        }
                    }
            }

            dirBefore = shelfs[dirX][dirY].getDirection();

        }
        
        if(dirBefore == 3 || dirBefore ==4){
            this.path = points;
            return;
        }
        
               
       
        
        for(int i = this.stopIndex; i < this.indexes.size(); i++){
            Point indexPoint = this.indexes.get(i);
            Point p2 = nextPath(indexPoint.x, indexPoint.y);

            int direction = shelfs[indexPoint.x][indexPoint.y].getDirection();

            //System.out.println(indexPoint.x + " " + indexPoint.y);

            /*DIVAM se na dalsi zastavky a podle smeru pristupnosti nastavim cestu -
            * pokud je 3 tak bod smazu, k nemu se uz nedostanu
            * pokud je 2 je dostupny ze spodu
            */
 /*
            Pokud je soucasny smer 0: dalsi 0 - vybery nejlepsi cestu
                                      dalsi 1 - prijdu z vrchu
                                      dalsi 2 - prijdu ze spodu
                                      dalsi 3 - skip
            Pokud je soucasny smer 1(prisel jsem z vrchu, nemuzu dolu)
            :                       dalsi 0 - prijdu ze z vrchu
                                    dalsi 1 - prijdu z vrchu
                                    dalsi 2 - obklicka, vratim se na predchozi ulicku, pokud je pruchodna
            Pokud je soucasny smer 2(prisel jsem z dolu, nemuzu vrchem)
            :                       dalsi 0 - prijdu ze spodu
                                    dalsi 1 - obklicka, vratim se na predchozi ulicku, pokud je pruchodna     
                                    dalsi 2 - ze spodu
            3 nenastane, snad         
            */

            if(direction == 3 || direction==4){         
                             
                if(this.stopIndex == i){
                    if(barrier){
                        this.stopIndex++;
                    } 
                }
                //this.stop.remove(i);
                //this.stopIndex++;
                
            }
         
            switch (dirBefore){
                case 0:
                    switch (direction){
                        case 0:
                            if (points.get(index).x < p2.x) {
                                if (maxY - p2.y > p2.y - 30) {     
                                    /*if(points.get(index).y != 30){
                                        points.add(new Point(points.get(index).x, 30));
                                    } else {
                                        index--;
                                    }*/
                                    points.add(new Point(points.get(index).x, 30));

                                    points.add(new Point(p2.x, 30));
                                    points.add(new Point(p2.x, p2.y));
                                } else {
                                   /* if(points.get(index).y != maxY+20){
                                        points.add(new Point(points.get(index).x, maxY+20));
                                    } else {
                                        index--;
                                    }*/
                                   points.add(new Point(points.get(index).x, maxY+20));

                                    points.add(new Point(p2.x, maxY+20));
                                    points.add(new Point(p2.x, p2.y));
                                }
                                index += 3;
                            } else if (points.get(index).y < p2.y) {
                                points.add(new Point(p2.x, p2.y));
                                index++;
                            } else if (points.get(index).y > p2.y) {
                                points.add(new Point(p2.x, p2.y));
                                index++;
                            }
                            break;
                            
                        case 1:
                            //System.out.format("(%d, %d) - (%d, %d)\n", points.get(index).x, points.get(index).y, p2.x, p2.y);
                            if(points.get(index).x == p2.x){
                                points.add(new Point(p2.x, p2.y));
                                index++;                               
                            } else {                                                                     
                                points.add(new Point(points.get(index).x, 30));
                                points.add(new Point(p2.x, 30));
                                points.add(new Point(p2.x, p2.y));
                                index += 3;
                            }
                            
                            break;
                        case 2:
                            if(points.get(index).x == p2.x){
                                System.out.println("HEER: " + points.get(index).y + " "+ p2.y);
                                points.add(new Point(p2.x, p2.y));
                                index++;
                            } else {  

                                points.add(new Point(points.get(index).x, maxY+20));
                                points.add(new Point(p2.x, maxY+20));
                                points.add(new Point(p2.x, p2.y));
                                index += 3;
                            }
                            break;
                        default:
                            break;
                    }
                    break;
                    
                case 1:
                    
                    switch(direction){
                        case 0:
                            points.add(new Point(points.get(index).x, 30));
                            points.add(new Point(p2.x, 30));
                            points.add(new Point(p2.x, p2.y));
                            
                            index += 3;
                            break;
                            
                        case 1:
                            if(points.get(index).x == p2.x){
                                points.add(new Point(p2.x, p2.y));
                                index++;
                            } else {
                                points.add(new Point(points.get(index).x, 30));
                                points.add(new Point(p2.x, 30));
                                points.add(new Point(p2.x, p2.y));
                                index += 3;
                            }
                            break;
                            
                        case 2:
                            //TODO
                            int freeIndex = closestFreeHallway(indexPoint.x, shelfs);
                            
                            if(freeIndex != -1){
                                int x = 200 + freeIndex*width+10;
                                
                                points.add(new Point(points.get(index).x, 30));
                                points.add(new Point(x, 30));
                                points.add(new Point(x, maxY+20));
                                points.add(new Point(p2.x, maxY+20));
                                points.add(new Point(p2.x, p2.y));
                                index += 5;
                            } else {
                                this.path = points;
                                return;
                            } 
                            
                            break;
                    }        
                    
                    break;
                    
                case 2:
                    
                    switch(direction){
                        case 0:
                            points.add(new Point(points.get(index).x, maxY+20));
                            points.add(new Point(p2.x, maxY+20));
                            points.add(new Point(p2.x, p2.y));
                            index += 3;
                            
                            break;                           
                        case 2:
                            if(points.get(index).x == p2.x){
                                points.add(new Point(p2.x, p2.y));
                                index++;
                            } else {                           
                                points.add(new Point(points.get(index).x, maxY+20));
                                points.add(new Point(p2.x, maxY+20));
                                points.add(new Point(p2.x, p2.y));
                                index += 3;
                            }
                            break;
                            
                        case 1:
                            //TODO
                            int freeIndex = closestFreeHallway(indexPoint.x, shelfs);
                            
                            if(freeIndex != -1){
                                int x = 200 + freeIndex*width+10;                               
                                points.add(new Point(points.get(index).x, maxY+20));
                                points.add(new Point(x, maxY+20));
                                points.add(new Point(x, 30));
                                points.add(new Point(p2.x, 30));
                                points.add(new Point(p2.x, p2.y));
                                index += 5;
                                
                            } else {
                                this.path = points;
                                return;
                            }
                            
                            break;
                    }                
                    break;
            }

            if (direction != 3 && direction !=4) {
                dirBefore = direction;
            }
        }

        //points.remove(0);
        points.add(new Point(points.get(points.size() - 1).x, maxY+20));
        points.add(new Point(50, maxY+20));
        
        this.path = points;
       
    }
    
    
    public int closestFreeHallway(int row, Shelf[][] shelfs) {
             
        for(int i = 0; i < shelfs.length; i+=3){
            if(row-i >= 0){
                Shelf s1 = shelfs[row-i][0];
                if(s1.getDirection() == 0){
                    return row - i;
                }
            }
            
            if(row+i < shelfs.length){
                Shelf s = shelfs[row+i][0];
                
                if(s.getDirection() == 0){
                    return row + i;
                }
            }
        }
        System.out.println("NOT VALID PATH");
        return -1;
    }
    
    public Point getIndex(int index) {
        return this.indexes.get(index);
    }

    public void addIndex(Point p) {
        this.indexes.add(p);
    }

    public void setFinished(boolean finished) {
        this.finished = finished;
    }

    public boolean isFinished() {
        return this.finished;
    }

    public int getClosestPoint(int timestamp) {
        int closest = 0;

        for (int i = 0; i < this.timePoints.size(); i++) {
            TimePoint p = this.timePoints.get(i);

            if (p.getTime() < timestamp) {
                closest = i;
            }
        }

        return closest;
    }

    public int timePointsSize() {
        return this.timePoints.size();
    }

    public TimePoint getTimePoint(int index) {
        return this.timePoints.get(index);
    }

    public void printTimePoints() {
        for (TimePoint p : this.timePoints) {
            System.out.println("Timestamp: " + p.getTime() + " list index: (" + p.getIndex().x + "," + p.getIndex().y + ") is stop? " + p.getStop());
        }
    }

    public int stopSize() {
        return this.stop.size();
    }

    public boolean isTakingGoods() {
        return this.takingGood;
    }

    public int getPointSize() {
        return this.path.size();
    }

    public void setStop(boolean takingGood) {
        this.sleep = 100;
        this.takingGood = takingGood;
    }

    public void setMapIndex(int mapIndex) {

        if (mapIndex < this.path.size()) {
            this.mapIndex = mapIndex;
        }
    }

    public void setStopIndex(int stopIndex) {
        if (stopIndex < this.stop.size()) {
            this.stopIndex = stopIndex;
        }
    }

    public int getMapIndex() {
        return this.mapIndex;
    }

    public void setSleep(int sleep) {
        this.sleep = sleep;
    }

    public int getTimeStop() {
        return this.sleep;
    }

    public int getStopIndex() {
        return this.stopIndex;
    }

    public void getCurrentPath(Polyline polyline) {
        polyline.getPoints().add((double)this.getX());
        polyline.getPoints().add((double)this.getY());
        for (int i = this.mapIndex+1; i < this.path.size(); i++) {
            Point p = this.path.get(i);
            polyline.getPoints().add((double) p.x);
            polyline.getPoints().add((double) p.y);
        }
    }

}
