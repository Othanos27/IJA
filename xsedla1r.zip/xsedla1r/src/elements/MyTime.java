/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package elements;

import Carriage.TimePoint;
import Order.IOrder;
import Order.Order;
import java.awt.Point;
import javafx.application.Platform;
import javafx.scene.control.Slider;
import javafx.scene.layout.Pane;
import javafx.scene.shape.Polyline;
import map.IWarehouseMap;
import map.WarehouseMap;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.scene.control.Label;

/**
 * timeline of animation
 * @author xzbori21
 */
public class MyTime implements Runnable {

    public ArrayList<Vehicle> vehicles;
    private Shelf[][] shelfs;

    private WarehouseMap warehouse;
    
    private int animationSpeed;
    private boolean pause = false;
    private boolean present = true;
    private int pastTime;
    private Slider timeline;

    private int time;

    public MyTime(Slider timeline) {
        vehicles = new ArrayList<>();
        animationSpeed = 1;
        time = 0;
        pastTime = 0;
        this.timeline = timeline;
    }

    public void setWarehouse(WarehouseMap warehouse){
        this.warehouse = warehouse;
    }

    /**
     * get shelf on given coords
     * @param number number of shelf
     * @param indexes coords
     * @return point on path
     */
    public Point getShelf(int number, ArrayList<Point> indexes) {

        int tmp = (number - 1) / this.shelfs[0].length;

        int row = tmp + 1 + tmp / 2;

        int column = (number - 1) % this.shelfs[0].length;

        System.out.println("AT: " + row + " "+column);
        //indexes.add(new Point(row, column));
        Shelf s = this.shelfs[row][column];

        Point p = new Point();
        //Pro vypocet stejne ulicky
        int rc = row - row / 3;

        if (rc % 2 == 1) {
            indexes.add(new Point(row - 1, column));
            p.x = 200 + 40 * row - 30;

        } else {
            indexes.add(new Point(row + 1, column));
            p.x = 200 + 40 * row + 50;
        }

        p.y = 50 + 40 * column + 20;
        
        System.out.println("AT: " + p.x + " "+p.y);
        
        return p;
    }

    /**
     * create carriage
     * @param pane javafx laying
     * @param warehouse where is placed
     * @param orders where is going
     * @return vehicle
     */
    public Vehicle createVehicle(Pane pane, WarehouseMap warehouse, ArrayList<Order> orders, Label label) {
        ArrayList<Point> points = new ArrayList<>();
        ArrayList<Point> shelfs = new ArrayList<>();
        ArrayList<Point> indexes = new ArrayList<>();

        points.add(new Point(50, 30));
        int index = 0;

        Map<Integer, List<Order>> map = warehouse.getPath(orders);
        
        
        List sortedKeys = new ArrayList<>(map.keySet());    
        Collections.sort(sortedKeys);

        String trajectory = "";
        int count = 1;
        
        for(Object i : sortedKeys){
            trajectory += "Regal - " +i + "; ";
            if(count % 2 == 0){
                trajectory+="\n";
            }
            
            count++;
            
            shelfs.add(getShelf((int)i, indexes));
        }
        
        
        label.setText(trajectory);
        

        /*points.remove(0);

        points.add(new Point(points.get(points.size() - 1).x, 230));
        points.add(new Point(700, 230));*/
        
        Vehicle v = new Vehicle(map, warehouse, points, shelfs, indexes);
        v.findNewPath(this.shelfs, 0, 0, false);
        v.setX(45.0);
        v.setY(30.0);

        pane.getChildren().add(v);

        Polyline p = new Polyline();

        /*Zobrazeni trasy*/
        v.setOnMouseEntered(event -> {
            v.getCurrentPath(p);
            pane.getChildren().add(p);
            if(present){
                label.setText(v.printCurrentLoad(time));
            } else {
                label.setText(v.printCurrentLoad(pastTime));
            }

        });

        v.setOnMouseExited(event -> {
            p.getPoints().clear();
            pane.getChildren().remove(p);
        });
        return v;
    }

    /**
     * add new vehicle
     * @param v vehicle
     */
    public void addVehicle(Vehicle v) {
        this.vehicles.add(v);
        System.out.println("ADDED");
        v.addTimePoint(new TimePoint(this.time, new Point(0, 0), false));
    }

    public void shelfsInit(Shelf[][] shelfs) {
        this.shelfs = shelfs;
    }

    public Point topBarrier(int row, int col) {
        Point index = new Point(-1, 0);

        this.shelfs[row][col].setDirection((short) 0);

        for (int i = 0; i < this.shelfs[0].length; i++) {
            Shelf s = this.shelfs[row][i];
            Shelf s2 = this.shelfs[row][this.shelfs[0].length - 1 - i];

            if (s.getDirection() == 4) {
                index.y = i;
            }

            if (s2.getDirection() == 4) {
                index.x = this.shelfs[0].length - i - 1;
            }
        }

        return index;
    }

    public void print(int row, int col, int height, boolean barrier) {
        if (this.shelfs == null) {
            return;
        }

        if (barrier) {
            for (int i = 0; i < this.shelfs[0].length; i++) {
                Shelf s = this.shelfs[row][i];

                if (i > col) {
                    if (s.getDirection() == 0) {
                        s.setDirection((short) 2);
                    } else if (s.getDirection() == 1) {
                        s.setDirection((short) 3);
                    }
                    /*Pokud je bariera pod blokem*/
                } else if (i < col) {
                    if (s.getDirection() == 0) {
                        s.setDirection((short) 1);
                    } else if (s.getDirection() == 2) {
                        s.setDirection((short) 3);
                    }

                } else {
                    s.setDirection((short) 4);
                }

                System.out.format("(%d, %d) - %d\n", row, col, s.getDirection());
            }
        } else {
            Point p = topBarrier(row, col);

            System.out.println("FOUND AT: " + p.x + " " + p.y);

            if (p.x == -1) {
                for (int i = 0; i < this.shelfs[0].length; i++) {
                    Shelf s = this.shelfs[row][i];
                    s.setDirection((short) 0);
                }
            } else {
                for (int i = 0; i < this.shelfs[0].length; i++) {
                    Shelf s = this.shelfs[row][i];

                    if (i < p.x) {
                        s.setDirection((short) 1);
                    } else if (i > p.y) {
                        s.setDirection((short) 2);
                    } else if (i > p.x && i < p.y) {
                        if (s.getDirection() != 4) {
                            s.setDirection((short) 3);
                        }
                    }
                }
            }
        }

        int x = 0;
        int y = 0;

        x = 205 + 20 * row;

        y = 60 + 20 * col;

        for (Vehicle v : this.vehicles) {
            //barrierIntersects(v, row, col);
            v.findNewPath(this.shelfs, row, col, barrier);        
        }
    }


    public void stop(boolean stop) {
        this.pause = stop;
    }

    public boolean isStopped() {
        return this.pause;
    }

    public void setPresent(boolean present) {
        this.present = present;
    }

    public boolean isPresent() {
        return this.present;
    }

    public void setAnimSpeed(int speed) {
        this.animationSpeed = speed;
    }

    public void setTime(double seconds) {
        for (Vehicle v : vehicles) {
            System.out.println("---------");
            v.printTimePoints();

            int timestamp = (int) (time * seconds);
            pastTime = timestamp;

            int closest = v.getClosestPoint(timestamp);

            TimePoint closestPoint = v.getTimePoint(closest);
            
            v.setMapIndex(closestPoint.getIndex().x);
            v.setStopIndex(closestPoint.getIndex().y);

            if (closestPoint.getStop() == true) {
                v.setX(v.getNextStop(v.getStopIndex() - 1).x);
                v.setY(v.getNextStop(v.getStopIndex() - 1).y);
            } else {
                int t1 = closestPoint.getTime();

                int t2 = closest < v.timePointsSize() - 1 ? v.getTimePoint(closest + 1).getTime() : time;

                double percentPath = (double) (timestamp - t1) / (double) (t2 - t1);

                //System.out.println(percentPath);
                //System.out.println(p2.x + " - " + p1.x);
                Point p2 = v.getNextPoint(v.getMapIndex() + 1);
                Point p1 = v.getNextPoint(v.getMapIndex());

                double dx = 0;
                double dy = 0;

                if (t2 != time) {
                    dx = p2.x - p1.x;
                    dy = p2.y - p1.y;
                } else {
                    dx = v.getX() - p1.x;
                    dy = v.getY() - p1.y;
                }

                v.setY(p1.y + (int) (dy * percentPath));
                v.setX(p1.x + (int) (dx * percentPath));
            }
        }
    }

    public void setCheckpoint(){
        for(Vehicle v : vehicles){
            v.addTimePoint(new TimePoint(time, new Point((int)v.getX(), (int)v.getY()), false));
        }
    }
    
    @Override
    public void run() {
        Runnable updater = () -> {
                
            if (pastTime >= time) {
                present = true;
                timeline.setValue(1.0);
            }
            
            for (int i = 0; i < vehicles.size(); i++) {
                Vehicle v = vehicles.get(i);
                
                
                if (v.getMapIndex() == v.getPointSize() - 1) {
                    //System.out.println("FINISHED");
                    continue;
                }
                
                if (v.isTakingGoods()) {
                    if (v.getTimeStop() == 0) {
                        v.setStop(false);
                        if (present) {
                            v.addTimePoint(new TimePoint(time, new Point(v.getMapIndex(), v.getStopIndex()), false));
                            v.setGoodPicked(time, warehouse);
                        }
                    } else {
                        v.setSleep(v.getTimeStop() - 1);
                    }
                    continue;
                }
                
                if(!present){
                    if(v.getMapIndex() == 0 && pastTime < v.getTimePoint(0).getTime()){
                        continue;
                    }
                }
                
                Point p = v.getNextPoint(v.getMapIndex() + 1);
                Point stop = v.getNextStop(v.getStopIndex());
                
                /*if(!present) {
                int index = v.getClosestPoint(pastTime);
                
                /*if(index + 1 < v.timePointsSize()) {
                System.out.println(index + " " + (v.timePointsSize()+1));
                TimePoint timepoint = v.getTimePoint(index + 1);
                p = v.getNextPoint(timepoint.getIndex().x);
                stop = v.getNextStop(timepoint.getIndex().y);
                }*/
                //}
                if ((p.x - (int) v.getX()) == 0) {
                    int step = p.y - v.getY() > 0 ? 1 : -1;
                    v.setY(v.getY() + step);
                } else {
                    int step = p.x - v.getX() > 0 ? 1 : -1;
                    v.setX(v.getX() + step);
                }
                
                if ((int) v.getX() == stop.x && (int) v.getY() == stop.y) {
                    
                    v.setStopIndex(v.getStopIndex() + 1);
                    
                    v.setStop(true);
                    
                    if (present) {
                        v.addTimePoint(new TimePoint(time, new Point(v.getMapIndex(), v.getStopIndex()), true));
                    }
                }
                
                if ((int) v.getX() == p.x && (int) v.getY() == p.y) {
                    //if(!isStopped){
                    v.setMapIndex(v.getMapIndex() + 1);
                                        
                    if (!v.isTakingGoods() && present) {
                        v.addTimePoint(new TimePoint(time, new Point(v.getMapIndex(), v.getStopIndex()), false));
                    }
                }
            }
            
            if (present) {
                time++;
            } else {
                pastTime++;
            };
        };

        while (true) {
            try {
                Thread.sleep(100 / animationSpeed);
            } catch (InterruptedException ex) {
                Logger.getLogger(MyTime.class.getName()).log(Level.SEVERE, null, ex);
            }
            if (!pause) {
                Platform.runLater(updater);
            }
        }
    }

}
