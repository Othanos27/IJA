/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package elements;

import javafx.scene.layout.StackPane;

/**
* handle accesibility of shelf
* @author xzbori21
*/

public class Shelf extends StackPane {
    
    private int number;
    
    /*0 - z obou stran; 1 - z vrchu; 2 - ze spodu; 3 - nedostupny*/
    private short direction;
    
    public Shelf(int number, short direction){
        this.number = number;
        this.direction = direction;
    }

    /**
     * id of shelf
     * @return int number
     */
    public int getNumber(){
        return this.number;
    }

    /**
     * set from which side is shelf accessible
     * @param direction 0 - both sides, 1 - up, 2 - down, 3 - is not accessible
     */
    public void setDirection(short direction){
        this.direction = direction;
    }

    /**
     * get from which side is shelf accessible
     * @return short direction (more in setDirection)
     */
    public short getDirection(){
        return this.direction;
    }
    
}
