package main;

import Order.IOrder;
import Order.Order;
import elements.MyTime;
import elements.Shelf;
import elements.Vehicle;
import ija.ija2020.homework1.goods.Goods;
import ija.ija2020.homework1.goods.GoodsItem;
import ija.ija2020.homework1.goods.GoodsShelf;
import ija.ija2020.homework1.store.StoreGoods;
import ija.ija2020.homework1.store.StoreShelf;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;
import java.net.URL;
import java.time.LocalDate;
import java.util.*;
import java.util.Map.Entry;
import java.util.logging.Level;
import java.util.logging.Logger;

import javafx.animation.PathTransition;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.geometry.Point2D;
import javafx.scene.Node;
import javafx.scene.control.*;
import javafx.scene.input.MouseEvent;
import javafx.scene.input.ScrollEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Text;
import javafx.stage.FileChooser;
import map.IWarehouseMap;
import map.WarehouseMap;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

/**
 * Controller for fxml file. Contains functions that control javafx components.
 * @author xsedla1r
 */

public class Controller implements Initializable {

    WarehouseMap warehouse = new WarehouseMap();

    ArrayList<Order> orders = new ArrayList();

    HashMap<String, Integer> mapGoods = new HashMap<>();

    /** Declaring javafx components */
    @FXML
    private AnchorPane pane;

    @FXML
    private Pane popup;

    @FXML
    private Label labelRegal;

    @FXML
    private GridPane grid;

    @FXML
    private Label labelObsahuje;
    @FXML
    private Label labelOrder;
    @FXML
    private Label labelTrasa;

    @FXML
    private Label labelPopup;
    @FXML
    private Label labelErrorPopup;

    @FXML
    private Button buttonNaplnSklad;
    @FXML
    private Button buttonNovyVozik;
    @FXML
    private Button buttonPozastavitAnimaci;

    @FXML
    private ListView listViewOrder;
    @FXML
    private ListView listViewList;

    @FXML
    private Spinner spinnerOrder;

    @FXML
    private Slider sliderSpeed;
    @FXML
    private Slider sliderTime;

    private MyTime timeline;

    /**
     * Things that happen immediately after initialization.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {

        this.popup.setVisible(false);

        sliderSpeed.setMax(10);
        sliderSpeed.setMin(1);
        sliderSpeed.setValue(1);
        sliderSpeed.setShowTickMarks(true);
        sliderSpeed.setMajorTickUnit(1);
        sliderSpeed.setShowTickLabels(true);
        sliderSpeed.setBlockIncrement(0.1f);

        sliderTime.setMax(1);
        sliderTime.setMin(0);
        sliderTime.setValue(1);
        sliderTime.setShowTickLabels(true);
    }

    /**
     * action for buttonNovyVozik
     * create new carriage
     */
    @FXML
    public void createVehicle() {
        //Vehicle v2 = timeline.createVehicle(pane, warehouse, orders);
        // timeline.addVehicle(v2);
    }

    /**
     * action for buttonPozastavitAnimaci
     * pause/play/stop animation of carriage
     */
    @FXML
    public void pauseAnimation() {

        if (!timeline.isStopped()) {
            timeline.stop(true);
            buttonPozastavitAnimaci.setText("Spustit animaci");
        } else {
            timeline.stop(false);
            buttonPozastavitAnimaci.setText("Zastavit animaci");
        }
    }

    /**
     * action onMouseEntered on rectangles which represent shelves
     * @param event MouseEvent
     * show what is inside of shelf where mouse is entered
     */
    @FXML
    public void showName(MouseEvent event) {
        String regalID = ((Rectangle) event.getSource()).getId().toString();
        String[] split = regalID.split("_", 2);
        int id = Integer.parseInt(split[1]);
        this.labelRegal.setText("Regal " + id);
        this.labelObsahuje.setText("Obsahuje: ");
        Iterator it = this.warehouse.getList().iterator();

        while (it.hasNext()) {
            GoodsShelf shelf = (GoodsShelf) it.next();
            if (shelf.getNumber() == id) {
                this.labelObsahuje.setText("Obsahuje: " + shelf.obsah());
                break;
            }
        }
    }

    /**
     * action onMouseExit on rectangles which represent shelves
     * hide label displayed in function showName
     */
    @FXML
    public void hideName() {
        this.labelRegal.setText("Najedte na regál");
        this.labelObsahuje.setText("");
    }

    /**
     * action on buttonNaplnSkladiste
     * open window for choosing json file with data for filling warehouse with goods
     * fill warehouse
     */
    @FXML
    public void fillWarehouse() {
        FileChooser fileChooser = new FileChooser();
        JSONParser parser = new JSONParser();
        File dir = new File("./data");
        fileChooser.setInitialDirectory(dir);

        fileChooser.setTitle("Vyberte soubor s příponou '.json'");
        fileChooser.getExtensionFilters().addAll(new FileChooser.ExtensionFilter("Soubory JSON", "*.json"));
        File warehouseFile = fileChooser.showOpenDialog(buttonNaplnSklad.getScene().getWindow());

        try {
            Reader reader = new FileReader(warehouseFile);
            Throwable var5 = null;

            try {
                JSONObject obj = (JSONObject) parser.parse(reader);
                JSONObject shelfObj = (JSONObject) obj.get("regaly");
                Iterator it = shelfObj.entrySet().iterator();

                while (it.hasNext()) {
                    Entry map = (Entry) it.next();
                    GoodsShelf storeShelf = new StoreShelf(Integer.parseInt(map.getKey().toString()));
                    Map shelf = (Map) shelfObj.get(map.getKey());
                    Iterator shelfIt = shelf.entrySet().iterator();

                    while (shelfIt.hasNext()) {
                        Entry shelfMap = (Entry) shelfIt.next();
                        Goods good = new StoreGoods(shelfMap.getKey().toString());

                        for (int i = 0; i < Integer.parseInt(shelfMap.getValue().toString()); ++i) {
                            GoodsItem item = good.newItem(LocalDate.now());
                            storeShelf.put(item);
                        }
                    }
                    this.warehouse.addShelf(storeShelf);
                }
            } catch (Throwable var26) {
                throw var26;
            } finally {
                if (reader != null) {
                    if (var5 != null) {
                        try {
                            reader.close();
                        } catch (Throwable var25) {
                            var5.addSuppressed(var25);
                        }
                    } else {
                        reader.close();
                    }
                }
            }
        } catch (ParseException | IOException var28) {
            System.out.println("Couldnt open file");
        }
    }

    /**
     * load map from file
     */
    @FXML 
    public void loadMap(){
        FileChooser fileChooser = new FileChooser();
        JSONParser parser = new JSONParser();
        File dir = new File("./data");
        fileChooser.setInitialDirectory(dir);

        fileChooser.setTitle("Vyberte soubor s příponou '.json'");
        fileChooser.getExtensionFilters().addAll(new FileChooser.ExtensionFilter("Soubory JSON", "*.json"));
        File warehouseFile = fileChooser.showOpenDialog(buttonNaplnSklad.getScene().getWindow());
        
          Reader reader;
        try {
            reader = new FileReader(warehouseFile);
            JSONObject obj = (JSONObject) parser.parse(reader);
            timeline = new MyTime(sliderTime);

            Thread updater = new Thread(timeline);
            
            JSONObject shelfObj = (JSONObject) obj.get("mapa");

            
            int row = Integer.parseInt(shelfObj.get("rows").toString());
            int col = Integer.parseInt(shelfObj.get("cols").toString());;
            
            
            initMap(timeline, row, col);
            timeline.setWarehouse(warehouse);
            updater.setDaemon(true);
            updater.start();
            sliderTime.valueProperty().addListener((ObservableValue<? extends Number> observable, Number oldValue, Number newValue) -> {
                if (sliderTime.getValue() != 1.0) {
                    if(timeline.isPresent()){
                        timeline.setCheckpoint();
                    }
                    timeline.setPresent(false);               
                } else {

                    timeline.setPresent(true);
                }

                timeline.setTime(sliderTime.getValue());
            });

            sliderSpeed.valueProperty().addListener((ObservableValue<? extends Number> observable, Number oldValue, Number newValue) -> {
                timeline.setAnimSpeed((int) sliderSpeed.getValue());
            });
            } catch (FileNotFoundException ex) {
                Logger.getLogger(Controller.class.getName()).log(Level.SEVERE, null, ex);
            } catch (IOException ex) {
                Logger.getLogger(Controller.class.getName()).log(Level.SEVERE, null, ex);
            } catch (ParseException ex) {
                Logger.getLogger(Controller.class.getName()).log(Level.SEVERE, null, ex);
            }
                Throwable var5 = null;

    }

    /**
     * action on buttonOrder and buttonPotvrdit
     * execute chosen order
     */
    @FXML
    public void executeOrder() {
        
        
        if (this.orders.isEmpty()) {
            this.labelTrasa.setText("Nezadano zadne zbozi");
            return;
        }
        if(!warehouse.executeOrder(orders, labelTrasa)){
            return;
        }
            ArrayList<Order> tmp = new ArrayList<>();

            for (int i = 1; i < this.orders.size()+1; i++) {
                tmp.add(this.orders.get(i-1));

                System.out.println(i);
                if ((i % 5 == 0 ) || i == this.orders.size()) {
                    System.out.println("PRIDAVA SE NOVE VOZIDLO:");
                    for(Order o : tmp){
                        System.out.println(o.getName() + " " + o.getCount());
                    }
                    Vehicle v2 = timeline.createVehicle(pane, warehouse, tmp, this.labelTrasa);
                    timeline.addVehicle(v2);
                    tmp.clear();
                }
            }

            this.orders.clear();
        
    }

    /**
     * initialize loaded map
     * @param timeline timeline
     * @param warehouseSize size of warehouse
     * @param columnLength length of column
     */
    public void initMap(MyTime timeline, int warehouseSize, int columnLength) {
        /*cteni ze souboru*/
        int count = 1;
        Shelf[][] shelfs = new Shelf[warehouseSize * 2 + warehouseSize + 1][columnLength];

        for (int i = 0; i < warehouseSize * 2 + warehouseSize + 1; i++) {
            if (i % 3 == 0) {
                for (int j = 0; j < columnLength; j++) {
                    Shelf s = new Shelf(count, (short) 0);
                    Rectangle r = new Rectangle();
                    r.setFill(Color.WHITE);
                    r.setWidth(40.0);
                    r.setHeight(40.0);
                    s.getChildren().addAll(r);

                    /*event handlery pracuji pouze s promennymi typu final*/
                    final int row = i;
                    final int col = j;

                    r.setOnMouseClicked(event -> {
                        /*VLOZENI PREKAZKY*/
                        if (timeline.isPresent()) {
                            if (r.getFill() == Color.RED) {
                                timeline.print(row, col, columnLength, false);
                                r.setFill(Color.WHITE);
                            } else {
                                timeline.print(row, col, columnLength, true);
                                r.setFill(Color.RED);
                                System.out.println(r.getLayoutX() + " " + r.getLayoutY());
                            }
                        }
                    });
                    shelfs[i][j] = s;
                    grid.add(s, i, j);
                }
            } else {
                for (int j = 0; j < columnLength; j++) {
                    Shelf s = new Shelf(count, (short) 0);
                    Text t = new Text("" + count);
                    Rectangle r = new Rectangle();
                    r.setFill(Color.ANTIQUEWHITE);
                    r.setWidth(40.0);
                    r.setHeight(40.0);
                    s.getChildren().addAll(r, t);
                    shelfs[i][j] = s;
                    grid.add(s, i, j);

                    s.setOnMouseEntered(event -> {
                        String goods = "";

                        if (warehouse == null) {
                            goods = "Prazdny";
                        } else {
                            goods = warehouse.printList(s.getNumber());
                        }

                        this.labelObsahuje.setText(goods);
                        r.setFill(Color.CHOCOLATE);
                    });
                    s.setOnMouseExited(event -> {
                        r.setFill(Color.ANTIQUEWHITE);
                    });

                    count++;

                }
            }
        }

        timeline.shelfsInit(shelfs);

        System.out.println("DONE");
    }

    /**
     * action on MenuItem "Rucne"
     * show pane for choosing order by hand
     */
    @FXML
    public void giveOrder() {
        this.popup.setVisible(true);
        labelPopup.setText("Zakliknete zbozi, které chcete vyzvednout\na navolte pocet");
        ArrayList<String> allGoodsTmp = new ArrayList<>();
        ArrayList<String> allGoods = new ArrayList<>();

        ArrayList<GoodsShelf> shelves = warehouse.getList();
        Iterator it = shelves.iterator();

        while (it.hasNext()) {
            GoodsShelf shelf = (GoodsShelf) it.next();
            allGoodsTmp.add(shelf.obsah());
        }

        it = allGoodsTmp.iterator();

        while (it.hasNext()) {
            String i = (String) it.next();
            String[] s = i.split(" ");
            for (int j = 0; j < s.length; j++) {
                allGoods.add(s[j]);
            }
        }

        allGoodsTmp.clear();

        int allGoodsSize = allGoods.size();
        for (int i = 0; i < allGoodsSize; i += 2) {
            allGoods.add(allGoods.get(i) + "-" + allGoods.get(i + 1));
        }
        for (int i = 0; i < allGoodsSize; i++) {
            allGoods.remove(0);
        }
        Collections.sort(allGoods);
        for (String s : allGoods) {
            allGoodsTmp.add(s.substring(0, s.length() - 1));
        }

        for (String s : allGoodsTmp) {
            String[] ss = s.split("-");
            mapGoods.put(ss[0], Integer.parseInt(ss[1]) + mapGoods.getOrDefault(ss[0], 0));
        }

        ArrayList<String> keys = new ArrayList<>(mapGoods.keySet());
        ArrayList<Integer> values = new ArrayList<>(mapGoods.values());

        allGoods.clear();
        for (int i = 0; i < keys.size(); i++) {
            String add = keys.get(i) + " (" + values.get(i) + " ks)";
            allGoods.add(add);
        }

        ObservableList<String> items = FXCollections.observableArrayList();
        items.setAll(keys);
        listViewOrder.setItems(items);
        listViewOrder.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
        labelOrder.setText("Objednavka:");
        SpinnerValueFactory<Integer> vf
                = new SpinnerValueFactory.IntegerSpinnerValueFactory(1, 100, 50);
        spinnerOrder.setValueFactory(vf);
        spinnerOrder.setEditable(true);
        /*from SO*/
        spinnerOrder.focusedProperty().addListener((observable, oldValue, newValue) -> {
            if (!newValue) {
                spinnerOrder.increment(0); // won't change value, but will commit editor
            }
        });
    }

    /**
     * action on MenuItem "Ze souboru"
     * open window for choosing json file with data for setting order
     * set order
     */
    @FXML
    public void orderFromFile() {
        FileChooser fileChooser = new FileChooser();
        JSONParser parser = new JSONParser();
        File dir = new File("./data");
        fileChooser.setInitialDirectory(dir);

        fileChooser.setTitle("Vyberte soubor s příponou '.json'");
        fileChooser.getExtensionFilters().addAll(new FileChooser.ExtensionFilter("Soubory JSON", "*.json"));
        File orderFile = fileChooser.showOpenDialog(pane.getScene().getWindow());

        try {
            Reader reader = new FileReader(orderFile);
            JSONObject obj = (JSONObject) parser.parse(reader);
            JSONObject shelfObj = (JSONObject) obj.get("objednavka");
            Iterator it = shelfObj.entrySet().iterator();

            while (it.hasNext()) {
                Entry map = (Entry) it.next();
 
                this.orders.add(new Order(map.getKey().toString(), Integer.parseInt(map.getValue().toString())));
                

            }
        } catch (FileNotFoundException ex) {
            Logger.getLogger(Controller.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(Controller.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ParseException ex) {
            Logger.getLogger(Controller.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * action on buttonPridat
     * add selected amount of selected good to order
     */
    @FXML
    public void addToOrder() {
        labelErrorPopup.setText("");
        ObservableList listViewOrderSelected = listViewOrder.getSelectionModel().getSelectedItems();
        int stock = mapGoods.get(listViewOrderSelected.get(0));
        if ((Integer) spinnerOrder.getValue() <= stock) {
            this.orders.add(new Order((String) listViewOrderSelected.get(0), (Integer) spinnerOrder.getValue()));
            listViewList.getItems().add(listViewOrderSelected.get(0) + ": " + spinnerOrder.getValue());
            mapGoods.put((String) listViewOrderSelected.get(0), stock - (Integer) spinnerOrder.getValue());
        } else {
            labelErrorPopup.setText("Ve skladu je pouze " + stock + " ks zboží " + listViewOrderSelected.get(0) + ".");
        }
    }

    /**
     * action on buttonPotvrdit
     * close pane for selecting order
     */
    @FXML
    public void saveOrder() {
        popup.setVisible(false);
    }

    /**
     * action on buttonClose
     * close pane for selecting order
     */
    @FXML
    public void closePopup() {
        this.popup.setVisible(false);
    }

    /**
     * function that enables zooming by scrolling
     * @param event scroll
     */
    @FXML
    public void zoom(ScrollEvent event
    ) {
        double zoomFactor = 1.05;
        double deltaY = event.getDeltaY();

        if (deltaY < 0) {
            zoomFactor = 0.95;
        }

        pane.setScaleX(pane.getScaleX() * zoomFactor);
        pane.setScaleY(pane.getScaleY() * zoomFactor);
        event.consume();
    }

    /** functions and variables for dragging */
    private Node selected;
    private Point2D translateStart;
    private Point2D offset;

    @FXML
    public void preDrag(MouseEvent event) {
        Node target = (Node) event.getTarget();

        if (target != pane) {
            selected = pane;
            offset = new Point2D(event.getX(), event.getY());
            translateStart = new Point2D(selected.getTranslateX(), selected.getTranslateY());
        } else {
            selected = pane;
        }
        event.consume();
    }

    @FXML
    public void drag(MouseEvent event) {
        if (selected != null) {
            selected.setTranslateX(event.getX() - offset.getX() + translateStart.getX());
            selected.setTranslateY(event.getY() - offset.getY() + translateStart.getY());
        }
        event.consume();
    }

}
