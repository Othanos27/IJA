/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Order;

/**
 * amount of items of goods to be picked up
 * @author xzbori21
 */
public class Order implements IOrder{

    private String name;
    
    private int count;
    
    private int timestamp = -1;
    
    public Order(String name, int count){
        this.name = name;
        this.count = count;
    }

    /**
     * name of goods
     * @return String name
     */
    @Override
    public String getName(){
            return this.name;
    }

    public void setTimeStamp(int timestamp){
        this.timestamp = timestamp;
    }
    
    public int getTimeStamp(){
        return this.timestamp;
    }
    
    public void setCount(int count){
        this.count = count;
    }

    /**
     * amount of items
     * @return int count
     */
    @Override
    public int getCount() {
           return this.count;
    }
    
}
