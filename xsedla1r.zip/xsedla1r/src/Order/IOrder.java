/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Order;

import ija.ija2020.homework1.goods.Goods;
import ija.ija2020.homework1.goods.GoodsItem;
import java.util.List;
import java.util.Map;

/**
 * interface order
 * @author xzbori21
 */
public interface IOrder {
    

    public String getName();
    
    public int getCount();
}
