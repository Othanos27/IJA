// 
// Decompiled by Procyon v0.5.36
// 
/**
 * interface StoreGoodsItem
 * @author xsedla1r
 */
package ija.ija2020.homework1.goods;

public interface GoodsItem
{
    Goods goods();
    
    boolean sell();
}
