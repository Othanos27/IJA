/**
 * interface StoreShelf
 * @author xsedla1r
 */

package ija.ija2020.homework1.goods;

import java.util.List;
import java.util.Map;

public interface GoodsShelf
{
    void put(final GoodsItem p0);
    
    boolean containsGoods(final Goods p0);
    
    GoodsItem removeAny(final Goods p0);
    
    int size(final Goods p0);
    
    int getNumber();
    
    String printShelf();
    
        public void removeGood(Goods good);

    public Map<Goods, List<GoodsItem>> getMap();

    String obsah();
}
