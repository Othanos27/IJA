package ija.ija2020.homework1.store;


import ija.ija2020.homework1.goods.Goods;
import ija.ija2020.homework1.goods.Goods;
import ija.ija2020.homework1.goods.GoodsItem;
import ija.ija2020.homework1.goods.GoodsItem;
import java.time.LocalDate;

/**
 * single item from StoreGoods
 * @author xsedla1r
 */
public class StoreGoodsItem implements GoodsItem {

    private Goods goods1;
    private LocalDate of;
    
    public StoreGoodsItem(Goods goods1, LocalDate of) {
        this.goods1 = goods1;
        this.of = of;
    }

    /**
     * type of goods
     * @return Goods goods
     */
    @Override
    public Goods goods() {
        return this.goods1;
    }

    /**
     * remove item from goods
     * @return boolean success
     */
    @Override
    public boolean sell() {
        return goods1.remove(this);
    }
    
}
