package ija.ija2020.homework1.store;


import ija.ija2020.homework1.goods.Goods;
import ija.ija2020.homework1.goods.GoodsItem;
import ija.ija2020.homework1.goods.GoodsShelf;
import ija.ija2020.homework1.goods.GoodsShelf;

import java.util.*;

/**
 * shelf where are stored GoodsItem
 * @author xsedla1r
 */

public class StoreShelf implements GoodsShelf {
    
    public Map<Goods, List<GoodsItem>> map;
    
    private int number;
    
    public StoreShelf(int number){
        this.map = new HashMap<>();
        this.number = number;
    }
    
    public StoreShelf(){
        this.map = new HashMap<>();
    }
    
    public void removeGood(Goods good){
        this.map.remove(good);
    }

    /**
     * id of shelf
     * @return int number
     */
    @Override
    public int getNumber(){
        return this.number;
    }
    
    public Map<Goods, List<GoodsItem>> getMap(){
        return this.map;
    }

    /**
     * store item to the shelf
     * @param p0 GoodsItem item to be stored
     */
    @Override
    public void put(GoodsItem p0){
        final Goods goods = p0.goods();
        
        if (this.map.containsKey(goods)) {
            this.map.get(goods).add(p0);
        }else {
            final List<GoodsItem> lst = new ArrayList<>();
            lst.add(p0);
            this.map.put(goods, lst);
        }
    }

    /**
     * print id of shelf, goods that contains and their amount of items
     */
    @Override
    public String printShelf(){
        String text = "";
        
        int count = 0;
        for(Map.Entry<Goods, List<GoodsItem>> entry : map.entrySet()){
            text += entry.getKey().getName() + " " + size(entry.getKey())+"; ";
            if(count%2 == 0 && count !=0){
                text += "\n";
            }
            count++;
        }
        return text;
    }

    /**
     * goods and its amount of items
     * @return String
     */
    @Override
    public String obsah() {
        String ret = "";

        Map.Entry entry;
        for(Iterator var2 = this.map.entrySet().iterator(); var2.hasNext(); ret = ret + ((Goods)entry.getKey()).getName() + " " + this.size((Goods)entry.getKey()) + "x ") {
            entry = (Map.Entry)var2.next();
        }

        return ret;
    }

    /**
     * check if shelf contains goods
     * @param p0 Goods goods to be checked
     * @return true if contains
     */
    @Override
    public boolean containsGoods(Goods p0) {
        final List<GoodsItem> lst = this.map.get(p0);

        return lst != null && !lst.isEmpty();
    }

    /**
     * remove all items of given goods
     * @param p0 Goods items of this goods to be removed
     * @return boolean success
     */
    @Override
    public GoodsItem removeAny(Goods p0) {
        final List<GoodsItem> lst = this.map.get(p0);
        if (lst == null || lst.isEmpty()) {
            return null;
        }
        
        return lst.remove(0);
    }

    /**
     * number of items in given goods
     * @param p0 Goods given goods
     * @return int size
     */
    @Override
    public int size(Goods p0) {
        final List<GoodsItem> lst = this.map.get(p0);
        if(lst == null){
            return 0;
        }
        return lst.size();
    }
    
}
