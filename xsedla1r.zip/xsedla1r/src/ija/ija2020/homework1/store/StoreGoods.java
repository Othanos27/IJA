package ija.ija2020.homework1.store;


import ija.ija2020.homework1.store.StoreGoodsItem;
import ija.ija2020.homework1.goods.Goods;
import ija.ija2020.homework1.goods.Goods;
import ija.ija2020.homework1.goods.GoodsItem;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Objects;

/**
 * type of goods
 * @author xzbori21
 */
public class StoreGoods implements Goods {

    private String name;
    private ArrayList<GoodsItem> items;
    
    public StoreGoods(String name) {
        this.name = name;
        this.items = new ArrayList<>();
    }

    /**
     * Get name of good
     * @return String name
     */
    @Override
    public String getName() {
        return this.name;
    }

    /**
     * add existing item to goods
     * @param p0 GoodsItem item to be added
     * @return boolean success
     */
    @Override
    public boolean addItem(GoodsItem p0) {
        try{
            this.items.add(p0);
        } catch(IndexOutOfBoundsException e){
            return false;
        }
        return true;
    }

    /**
     * add new item to goods
     * @param p0 LocalDate date and time
     * @return StoreGoodsItem item
     */
    @Override
    public GoodsItem newItem(LocalDate p0) {
        final StoreGoodsItem item = new StoreGoodsItem(this, p0);
        addItem(item);
        return  item;
    }

    /**
     * remove item from goods
     * @param p0 GoodsItem item to be removed
     * @return boolean success
     */
    @Override
    public boolean remove(GoodsItem p0) {
          try{
            this.items.remove(p0);
        } catch(IndexOutOfBoundsException e){
            return false;
        }
        return true;
    }

    /**
     * check if goods is empty
     * @return true if empty
     */
    @Override
    public boolean empty() {
        if(this.items.isEmpty()){
            return true;
        } else {
            return false;
        }
    }

    /**
     * number of items in goods
     * @return int size
     */
    @Override
    public int size() {
        return this.items.size();
    }

    /**
     * hash code of name of goods
     * @return int hash
     */
    @Override
    public int hashCode() {
        int hash = 5;
        hash = 89 * hash + Objects.hashCode(this.name);
        return hash;
    }

    /**
     * compare two objects
     * @param obj object to be compared with
     * @return true if objects equal
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final StoreGoods other = (StoreGoods) obj;
        if (!Objects.equals(this.name, other.name)) {
            return false;
        }
        return true;
    }
    
}
