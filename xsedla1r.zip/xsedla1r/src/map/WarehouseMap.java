/* *
 *
 *

 */
package map;

import Order.IOrder;
import Order.Order;
import ija.ija2020.homework1.goods.Goods;
import ija.ija2020.homework1.goods.GoodsItem;
import ija.ija2020.homework1.goods.GoodsShelf;
import ija.ija2020.homework1.store.StoreGoods;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javafx.scene.control.Label;

/**
 * warehouse that contains of GoodsShelf
 * @author xzbori21
 */
public class WarehouseMap implements IWarehouseMap {

    private ArrayList<GoodsShelf> shelfs;

    public WarehouseMap() {
        this.shelfs = new ArrayList<>();
    }

    /**
     * list of all shelves in warehouse
     * @return ArrayList(GoodsShelf) shelves
     */
    public ArrayList<GoodsShelf> getList() {
        return this.shelfs;
    }

    /**
     * add shelf to warehouse
     * @param shelf GoodsShelf shelf to be added
     */
    @Override
    public void addShelf(GoodsShelf shelf) {
        this.shelfs.add(shelf);
    }

    /**
     * remove shelf from warehouse
     * @param shelf GoodsShelf shelf to be removed
     */
    @Override
    public void removeShelf(GoodsShelf shelf) {
        this.shelfs.remove(shelf);
    }

    /**
     * print all Goods in warehouse
     */
    @Override
    public String printList(int number) {

        for (GoodsShelf shelf : shelfs) {
            if (shelf.getNumber() == number) {
                return shelf.printShelf();
            }
        }

        return "prazdny";
    }

    /*Vime ze mame potrebne zbozi, nemusime to kontrolovat*/
    @Override
    public void put(Map<Integer, List<Order>> map, Integer index, Order order) {
        if (map.containsKey(index)) {
            map.get(index).add(order);
        } else {
            final List<Order> list = new ArrayList<>();
            list.add(order);
            map.put(index, list);
        }
    }

    public void removeGoodFromShelf(int number, List<Order> orders) {

        for (GoodsShelf shelf : shelfs) {
            if (shelf.getNumber() == number) {
                for (Order o : orders) {
                    List<GoodsItem> list = shelf.getMap().get(new StoreGoods(o.getName()));

                    System.out.println("WANT TO REMOVE " + o.getName() + " " + o.getCount() + " " + list.size());
                    if (o.getCount() >= list.size()) {
                        shelf.removeGood(new StoreGoods(o.getName()));
                       // o.setCount(o.getCount() - list.size());
                    } else {
                        for (int i = 0; i < o.getCount(); i++) {
                            list.remove(0);
                        }
                    }
                }
            }
        }
    }

    /**
     * get path for carriage
     * @param orders list of orders to be done
     * @return Map path
     */
    @Override
    public Map<Integer, List<Order>> getPath(ArrayList<Order> orders) {

        Map<Integer, List<Order>> map = new HashMap<>();

        /*prochazim objednavky postupne a zaznamenam si */
        for (IOrder o : orders) {
            Goods good = new StoreGoods(o.getName());
            int count = o.getCount();

            for (GoodsShelf s : this.shelfs) {
                if (s.containsGoods(good)) {
                    System.out.println("test: " + s.getNumber());
                    if (count < s.size(good)) {
                        put(map, s.getNumber(), new Order(o.getName(), count));
                        break;
                    } else {
                        /*Pokud celkova velikost je vetsi, musim to rozdelit do vice regalu*/
                        put(map, s.getNumber(), new Order(o.getName(), s.size(good)));
                        count -= s.size(good);
                    }
                }
            }
        }

        return map;
    }

    /**
     * check if amount of items in order is not bigger than in warehouse
     * @param orders order
     * @return true if order -le in warehouse
     */
    @Override
    public boolean executeOrder(ArrayList<Order> orders, Label label) {

        for (IOrder o : orders) {
            int count = 0;
            Goods good = new StoreGoods(o.getName());
            boolean contains = false;

            for (GoodsShelf s : this.shelfs) {
                if (s.containsGoods(good)) {
                    count += s.size(good);
                    contains = true;
                }
            }

            if (!contains) {

                label.setText(o.getName() + " neni na skladu");
                return false;

            }
            if (o.getCount() > count) {
                label.setText("Pocet " + o.getName() + " neni skladem.\nPozadovane: " + o.getCount() + "\nDostupne: " + count);
                return false;
            }
        }

        return true;
    }

}
