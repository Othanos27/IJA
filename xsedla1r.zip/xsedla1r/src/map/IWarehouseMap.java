
package map;

import Order.IOrder;
import Order.Order;
import ija.ija2020.homework1.goods.GoodsShelf;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import javafx.scene.control.Label;

/**
 * interface warehouseMap
 * @author xzbori21
 */
public interface IWarehouseMap {
    
    void addShelf(final GoodsShelf shelf);
    
    void removeShelf(final GoodsShelf shelf);
    
    Map<Integer, List<Order>> getPath(ArrayList<Order> orders);
    
    void put(Map<Integer, List<Order>> map, Integer index, Order order);
    
    String printList(int number);
    
    boolean executeOrder(ArrayList<Order> orders, Label label);
    
    
}
