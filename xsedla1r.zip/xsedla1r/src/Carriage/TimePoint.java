/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Carriage;

import java.awt.*;

/**
 * current time
 * @author xzbori21
 */

public class TimePoint {
    private int time;
    private Point index;
    private boolean isStop;
    
    public TimePoint(int time, Point index, boolean isStop) {
        this.time = time;
        this.index = index;
        this.isStop = isStop;
    }
    
    public boolean getStop(){
        return this.isStop;
    }   
    
    public int getTime() {
        return time;
    }

    public Point getIndex(){
        return this.index;
    }
    
    public void setTime(int time) {
        this.time = time;
    }

     

   
    
   
}
