/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Carriage;

import ija.ija2020.homework1.goods.Goods;
import ija.ija2020.homework1.goods.GoodsItem;
import ija.ija2020.homework1.goods.GoodsShelf;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * carriage which do the order
 * @author xzbori21
 */

public class Carriage {
    private int capacity;
    private boolean busy;
    private GoodsShelf shelf;

    public Carriage(int capacity, boolean busy){
        this.capacity = capacity;
        this.busy = busy;
    }

    /**
     * get capacity of carriage
     * @return int capacity
     */
    public int getCapacity(){
        return this.capacity;
    }

    /**
     * check if carriage is used
     * @return boolean true if is busy
     */
    public boolean isBusy(){
        return this.busy;
    }
    
    public void loadCarriage(String name, int count){
        
    }

    /**
     * set if carriage is busy
     * @param busy boolean
     */
    public void setBusy(boolean busy){
        this.busy = busy;
    }
    
    
}
