Aplikace pro vizualizaci pohybu a stavu zboží ve skladišti

autoři: xsedla1r, xzbori21

verze Javy: JDK 8

Jako demonstrační třídu jsem zvolil vizualizaci pomocí GUI. Pro názornost jsem implementoval kolegovu 
demonstrační třídu main do mé třídy Controller. Pomocí jeho třídy jsem naplnil sklad a vypsal cestu, pomocí
mé třídy jsem tyto věci převedl do GUI + jsem přidal drobnosti, které můžete vidět při běhu aplikace. 

Při najetí na regál se zobrazí jeho obsah, při výpisu cesty se barevně označí regály, u kterých bude vozík zastavovat.
Funkce jsou implementovány zatím pouze pro prvních 10 regálů.